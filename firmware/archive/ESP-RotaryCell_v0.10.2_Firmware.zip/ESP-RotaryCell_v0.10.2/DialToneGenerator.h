#pragma once
#include <Arduino.h>

class DialToneGenerator {
public:
  void begin();
  void start();
  void stop();
  bool isActive() const;

private:
  static void timerThunk(void* arg);
  void onSample();
  void writeDuty(uint8_t duty);

  static constexpr uint16_t SAMPLE_RATE_HZ = 4000;
  static constexpr uint16_t TABLE_LENGTH = 400; // 100 ms: exact cycles for 350 + 440 Hz

  uint8_t _samples[TABLE_LENGTH]{};
  volatile uint16_t _sampleIndex = 0;
  volatile bool _active = false;
  void* _timer = nullptr;
};
