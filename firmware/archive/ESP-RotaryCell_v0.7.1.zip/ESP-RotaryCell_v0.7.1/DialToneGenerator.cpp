#include "DialToneGenerator.h"
#include "Config.h"
#include <esp_timer.h>
#include <math.h>

#if __has_include(<esp_arduino_version.h>)
#include <esp_arduino_version.h>
#endif

namespace {
constexpr uint32_t PWM_FREQUENCY_HZ = 31250;
constexpr uint8_t PWM_RESOLUTION_BITS = 8;
constexpr uint8_t PWM_IDLE_DUTY = 127;
constexpr uint8_t PWM_CHANNEL = 0; // Used only with Arduino-ESP32 2.x.
}

void DialToneGenerator::begin() {
  // GPIO36 is a camera data pin on the LilyGO S3-Standard layout. The camera
  // interface is unused in ESP-RotaryCell, so it is available for dial tone.
#if defined(ESP_ARDUINO_VERSION_MAJOR) && ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcAttach(PIN_DIAL_TONE, PWM_FREQUENCY_HZ, PWM_RESOLUTION_BITS);
  ledcWrite(PIN_DIAL_TONE, PWM_IDLE_DUTY);
#else
  ledcSetup(PWM_CHANNEL, PWM_FREQUENCY_HZ, PWM_RESOLUTION_BITS);
  ledcAttachPin(PIN_DIAL_TONE, PWM_CHANNEL);
  ledcWrite(PWM_CHANNEL, PWM_IDLE_DUTY);
#endif

  // Generate one exact 100 ms period of North-American dial tone:
  // 350 Hz + 440 Hz.  Keep generous headroom to avoid PWM clipping.
  for (uint16_t i = 0; i < TABLE_LENGTH; ++i) {
    const float t = static_cast<float>(i) / SAMPLE_RATE_HZ;
    const float mixed = sinf(2.0f * PI * 350.0f * t) +
                        sinf(2.0f * PI * 440.0f * t);
    int value = static_cast<int>(127.0f + 48.0f * mixed);
    value = constrain(value, 0, 255);
    _samples[i] = static_cast<uint8_t>(value);
  }

  esp_timer_create_args_t args{};
  args.callback = &DialToneGenerator::timerThunk;
  args.arg = this;
  args.dispatch_method = ESP_TIMER_TASK;
  args.name = "dialtone";

  esp_timer_handle_t handle = nullptr;
  if (esp_timer_create(&args, &handle) == ESP_OK) {
    _timer = handle;
  } else {
    Serial.println("DIAL TONE: timer creation failed");
  }
}

void DialToneGenerator::start() {
  if (_active || _timer == nullptr) {
    return;
  }

  _sampleIndex = 0;
  _active = true;
  writeDuty(_samples[0]);

  const uint64_t intervalUs = 1000000ULL / SAMPLE_RATE_HZ;
  if (esp_timer_start_periodic(static_cast<esp_timer_handle_t>(_timer), intervalUs) != ESP_OK) {
    _active = false;
    writeDuty(PWM_IDLE_DUTY);
    Serial.println("DIAL TONE: timer start failed");
    return;
  }

  Serial.println("DIAL TONE: ON (350 + 440 Hz)");
}

void DialToneGenerator::stop() {
  if (!_active) {
    return;
  }

  _active = false;
  if (_timer != nullptr) {
    esp_timer_stop(static_cast<esp_timer_handle_t>(_timer));
  }
  writeDuty(PWM_IDLE_DUTY);
  Serial.println("DIAL TONE: OFF");
}

bool DialToneGenerator::isActive() const {
  return _active;
}

void DialToneGenerator::timerThunk(void* arg) {
  static_cast<DialToneGenerator*>(arg)->onSample();
}

void DialToneGenerator::onSample() {
  if (!_active) {
    return;
  }

  writeDuty(_samples[_sampleIndex]);
  ++_sampleIndex;
  if (_sampleIndex >= TABLE_LENGTH) {
    _sampleIndex = 0;
  }
}

void DialToneGenerator::writeDuty(uint8_t duty) {
#if defined(ESP_ARDUINO_VERSION_MAJOR) && ESP_ARDUINO_VERSION_MAJOR >= 3
  ledcWrite(PIN_DIAL_TONE, duty);
#else
  ledcWrite(PWM_CHANNEL, duty);
#endif
}
