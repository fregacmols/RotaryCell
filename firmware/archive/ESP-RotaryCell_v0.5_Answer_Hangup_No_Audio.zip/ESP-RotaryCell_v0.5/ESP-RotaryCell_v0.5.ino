#include "Config.h"
#include "PhoneLine.h"
#include "RingGenerator.h"
#include "BatteryMonitor.h"
#include "Modem.h"
#include "Console.h"

PhoneLine phoneLine;
RingGenerator ringGenerator;
BatteryMonitor batteryMonitor;
Modem modem;
Console console(phoneLine, ringGenerator, batteryMonitor, modem);

bool previousOffHook = false;

void setup() {
  Serial.begin(SERIAL_BAUD);
  delay(750);

  phoneLine.begin();
  ringGenerator.begin();
  batteryMonitor.begin();
  modem.begin();
  console.begin();

  previousOffHook = phoneLine.isOffHook();
}

void loop() {
  phoneLine.update();
  ringGenerator.update();
  batteryMonitor.update();
  modem.update();
  console.update();

  // A new cellular call starts the physical bell only while on hook.
  if (modem.takeIncomingCallStarted()) {
    Serial.println();
    Serial.println("CELLULAR: incoming call");

    if (modem.callerId().length() > 0) {
      Serial.print("CALLER ID: ");
      Serial.println(modem.callerId());
    }

    if (phoneLine.isOffHook()) {
      Serial.println("CELLULAR: handset already off hook; answering");
      modem.answerIncomingCall();
    } else {
      ringGenerator.startIncomingCadence();
    }
  }

  // Stop the physical bell when the remote caller disconnects.
  if (modem.takeIncomingCallEnded()) {
    if (ringGenerator.isIncomingCadence()) {
      ringGenerator.stop();
    }
    Serial.println("CELLULAR: call ended");
  }

  const bool offHook = phoneLine.isOffHook();

  // Answer only on the transition from on-hook to off-hook.
  if (offHook && !previousOffHook) {
    if (ringGenerator.isActive()) {
      ringGenerator.stop();
      Serial.println("RING: stopped because handset went off hook");
    }

    if (modem.isIncomingCall()) {
      modem.answerIncomingCall();
      Serial.println("CELLULAR: call answered; voice audio is not connected yet");
    }
  }

  // Hanging up the handset ends an answered cellular call.
  if (!offHook && previousOffHook && modem.isCallActive()) {
    modem.hangUp();
    Serial.println("CELLULAR: call ended because handset went on hook");
  }

  previousOffHook = offHook;
}
