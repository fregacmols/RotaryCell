#include "Config.h"
#include "PhoneLine.h"
#include "RingGenerator.h"
#include "Console.h"

PhoneLine phoneLine;
RingGenerator ringGenerator;
Console console(phoneLine, ringGenerator);

void setup() {
  Serial.begin(SERIAL_BAUD);
  delay(750);
  phoneLine.begin();
  ringGenerator.begin();
  console.begin();
}

void loop() {
  phoneLine.update();
  ringGenerator.update();
  console.update();

  if (phoneLine.isOffHook() && ringGenerator.isActive()) {
    ringGenerator.stop();
    Serial.println("RING: stopped because handset went off hook");
  }
}
