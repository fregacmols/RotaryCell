#include "Console.h"
#include "Config.h"
#include "PhoneLine.h"
#include "RingGenerator.h"

Console::Console(PhoneLine& phoneLine, RingGenerator& ringGenerator)
  : _phoneLine(phoneLine), _ringGenerator(ringGenerator) {}

void Console::begin() {
  Serial.println();
  Serial.println("ESP-RotaryCell v0.2");
  Serial.println("Ag1171 line and rotary diagnostic firmware");
  printHelp();
}

void Console::update() {
  while (Serial.available()) {
    const char incoming = static_cast<char>(Serial.read());
    if (incoming == '\r' || incoming == '\n' || incoming == ' ') continue;
    handleCommand(static_cast<char>(toupper(incoming)));
  }
}

void Console::handleCommand(char command) {
  switch (command) {
    case '?': printHelp(); break;
    case 'S': printStatus(); break;
    case 'P':
      _phoneLine.setVerbosePulses(!_phoneLine.verbosePulses());
      Serial.print("VERBOSE PULSE MODE: ");
      Serial.println(_phoneLine.verbosePulses() ? "ON" : "OFF");
      break;
    case 'R':
      if (_phoneLine.isOffHook()) Serial.println("RING REFUSED: replace handset first");
      else _ringGenerator.startTest();
      break;
    case 'C':
      if (_phoneLine.isOffHook()) Serial.println("RING REFUSED: replace handset first");
      else _ringGenerator.startCadence();
      break;
    case 'X':
      _ringGenerator.stop();
      Serial.println("RING: stopped");
      break;
    default:
      Serial.print("UNKNOWN COMMAND: ");
      Serial.println(command);
      Serial.println("Type ? for help.");
      break;
  }
}

void Console::printHelp() const {
  Serial.println();
  Serial.println("Commands:");
  Serial.println("  ?  Help");
  Serial.println("  S  Status");
  Serial.println("  P  Toggle verbose rotary-pulse display");
  Serial.println("  R  One-second ring test");
  Serial.println("  C  One complete ring cadence");
  Serial.println("  X  Stop ringing");
  Serial.println();
}

void Console::printStatus() const {
  Serial.println();
  Serial.println("--- ESP-RotaryCell status ---");
  Serial.print("Handset: ");
  Serial.println(_phoneLine.isOffHook() ? "OFF HOOK" : "ON HOOK");
  Serial.print("Raw SHK interpretation: ");
  Serial.println(_phoneLine.rawOffHook() ? "OFF HOOK" : "ON HOOK");
  Serial.print("Pending dial pulses: ");
  Serial.println(_phoneLine.pendingPulseCount());
  Serial.print("Verbose pulse mode: ");
  Serial.println(_phoneLine.verbosePulses() ? "ON" : "OFF");
  Serial.print("Ring state: ");
  Serial.println(_ringGenerator.modeName());
  Serial.print("GPIO ");
  Serial.print(PIN_SHK);
  Serial.print(" electrical level: ");
  Serial.println(digitalRead(PIN_SHK) == HIGH ? "HIGH" : "LOW");
  Serial.println("-----------------------------");
  Serial.println();
}
