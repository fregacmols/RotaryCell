#pragma once
#include <Arduino.h>
class PhoneLine;
class RingGenerator;

class Console {
public:
  Console(PhoneLine& phoneLine, RingGenerator& ringGenerator);
  void begin();
  void update();
private:
  void printHelp() const;
  void printStatus() const;
  void handleCommand(char command);
  PhoneLine& _phoneLine;
  RingGenerator& _ringGenerator;
};
