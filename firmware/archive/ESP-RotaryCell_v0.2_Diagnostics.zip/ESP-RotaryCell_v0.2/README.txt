ESP-RotaryCell v0.2
===================

This diagnostic build adds:
- Correct active-high SHK handling
- Rotary digit decoding from Ag1171 SHK pulses
- Verbose pulse timing mode
- One-second ring test
- One complete 2-second-on / 4-second-off cadence
- Automatic ring shutdown when the handset is lifted

Arduino IDE:
Board: ESP32S3 Dev Module
USB CDC On Boot: Enabled
Serial Monitor: 115200 baud

Ag1171 wiring:
GPIO15 -> F/R
GPIO16 -> RM
GPIO37 <- SHK

Commands:
? Help
S Status
P Toggle verbose pulse timing
R One-second ring test
C One complete cadence
X Stop ringing

Test rotary decoding by lifting the handset and dialing. Completed digits
should print as DIGIT: n. Ten pulses are reported as digit 0.

Only run a ring test with the handset fully replaced. The firmware also
refuses to start ringing while it believes the handset is off hook.

This version intentionally does not initialize the A7670G modem. Modem UART
support will be added after confirming the exact Standard-board modem pinout.
