#pragma once
#include <Arduino.h>

constexpr uint8_t PIN_FR  = 15;
constexpr uint8_t PIN_RM  = 16;
constexpr uint8_t PIN_SHK = 37;
constexpr bool SHK_ACTIVE_HIGH = true;
constexpr uint32_t SERIAL_BAUD = 115200;
constexpr uint16_t SHK_DEBOUNCE_MS       = 8;
constexpr uint16_t DIAL_PULSE_MIN_MS     = 25;
constexpr uint16_t DIAL_PULSE_MAX_MS     = 140;
constexpr uint16_t DIGIT_COMPLETE_MS     = 250;
constexpr uint16_t HANGUP_CONFIRM_MS     = 500;
constexpr uint16_t RING_HALF_PERIOD_MS   = 25;
constexpr uint32_t RING_TEST_DURATION_MS = 1000;
constexpr uint32_t CADENCE_RING_ON_MS    = 2000;
constexpr uint32_t CADENCE_RING_OFF_MS   = 4000;
