#include "Modem.h"
#include "Config.h"

void Modem::begin() {
  Serial.println();
  Serial.println("MODEM: starting A7670G interface");

  // LilyGO documents GPIO42 HIGH as maximum power capability.
  pinMode(PIN_MODEM_POWER_SAVE, OUTPUT);
  digitalWrite(PIN_MODEM_POWER_SAVE, HIGH);

  // Keep the modem awake.
  pinMode(PIN_MODEM_DTR, OUTPUT);
  digitalWrite(PIN_MODEM_DTR, LOW);

  pinMode(PIN_MODEM_RING, INPUT_PULLUP);

  // LilyGO A7670G-S3 PWRKEY sequence idles LOW and uses a HIGH pulse.
  pinMode(PIN_MODEM_PWRKEY, OUTPUT);
  digitalWrite(PIN_MODEM_PWRKEY, LOW);

  _serial.begin(MODEM_BAUD, SERIAL_8N1, PIN_MODEM_RX, PIN_MODEM_TX);
  delay(150);

  Serial.println("MODEM: checking for an existing AT response");
  if (!waitForAT(2500)) {
    Serial.println("MODEM: no response; issuing a PWRKEY wake pulse");
    pulsePowerKey();

    const uint32_t startedAt = millis();
    while (millis() - startedAt < MODEM_BOOT_WAIT_MS) {
      readSerial();
      delay(10);
    }

    if (!waitForAT(3000)) {
      Serial.println("MODEM: still not responding");
      Serial.println("MODEM: use command W to retry PWRKEY, or A for AT terminal");
      return;
    }
  }

  _online = true;
  Serial.println("MODEM: responding");
  configureModem();
  requestStatus();
}

bool Modem::waitForAT(uint32_t timeoutMs) {
  while (_serial.available()) {
    _serial.read();
  }

  _serial.print("AT\r\n");
  const uint32_t startedAt = millis();
  String response;

  while (millis() - startedAt < timeoutMs) {
    while (_serial.available()) {
      const char c = static_cast<char>(_serial.read());
      response += c;
      if (response.indexOf("OK") >= 0) {
        return true;
      }
    }
    delay(5);
  }

  return false;
}

void Modem::configureModem() {
  // Echo off, verbose errors, caller ID, extended call result codes,
  // and registration URCs.
  sendRaw("ATE0");
  delay(100);
  sendRaw("AT+CMEE=2");
  delay(100);
  sendRaw("AT+CLIP=1");
  delay(100);
  sendRaw("AT+CRC=1");
  delay(100);
  sendRaw("AT+CREG=2");
  delay(100);
  sendRaw("AT+CEREG=2");
  delay(100);

  // LilyGO T-A7670G-S3 Standard: modem GPIO3 enables the onboard
  // speaker power amplifier.  Also select the speaker audio path and
  // restore the receive gain established during bench testing.
  configureVoiceAudio();
}

void Modem::configureVoiceAudio() {
  Serial.println("MODEM: configuring voice audio / speaker amplifier");
  sendRaw("AT+CGDRT=3,1");
  delay(100);
  sendRaw("AT+CGSETV=3,1");
  delay(100);
  sendRaw("AT+CSDVC=3");
  delay(100);
  sendRaw("AT+COUTGAIN=7");
  delay(100);
}

void Modem::pulsePowerKey() {
  Serial.println("MODEM: PWRKEY LOW 100 ms, HIGH 1000 ms, then LOW");
  digitalWrite(PIN_MODEM_PWRKEY, LOW);
  delay(MODEM_POWERKEY_LOW_PREP_MS);
  digitalWrite(PIN_MODEM_PWRKEY, HIGH);
  delay(MODEM_POWERKEY_HIGH_MS);
  digitalWrite(PIN_MODEM_PWRKEY, LOW);
}

void Modem::update() {
  readSerial();

  const uint32_t now = millis();

  // Incoming-call URCs normally repeat. If they stop without an explicit
  // NO CARRIER, release the ringing state after a generous timeout.
  if (_incomingCall &&
      _lastRingAt > 0 &&
      now - _lastRingAt >= MODEM_RING_TIMEOUT_MS) {
    Serial.println("MODEM: ring URC timeout");
    setIncomingCall(false);
  }

  // Status polling is manual only (console command M).
}

void Modem::readSerial() {
  while (_serial.available()) {
    const char c = static_cast<char>(_serial.read());

    if (c == '\r') {
      continue;
    }

    if (c == '\n') {
      if (_lineBuffer.length() > 0) {
        processLine(_lineBuffer);
        _lineBuffer = "";
      }
      continue;
    }

    if (_lineBuffer.length() < 255) {
      _lineBuffer += c;
    } else {
      _lineBuffer = "";
    }
  }
}

void Modem::processLine(String line) {
  line.trim();
  if (line.length() == 0) {
    return;
  }

  Serial.print("[MODEM] ");
  Serial.println(line);

  if (line == "OK") {
    _online = true;
    return;
  }

  if (line == "RING" || line.startsWith("+CRING:")) {
    _lastRingAt = millis();
    setIncomingCall(true);
    return;
  }

  if (line == "NO CARRIER" ||
      line == "BUSY" ||
      line == "NO ANSWER" ||
      line == "NO DIALTONE") {
    if (line == "BUSY") {
      _callResultEvent = CallResult::BUSY;
    } else if (line == "NO ANSWER") {
      _callResultEvent = CallResult::NO_ANSWER;
    } else if (line == "NO DIALTONE") {
      _callResultEvent = CallResult::NO_DIALTONE;
    } else {
      _callResultEvent = CallResult::NO_CARRIER;
    }

    _callActive = false;
    setIncomingCall(false);
    return;
  }

  if (line.startsWith("+CLIP:")) {
    parseClip(line);
    return;
  }

  if (line.startsWith("+CPIN:")) {
    parseCpin(line);
    return;
  }

  if (line.startsWith("+CSQ:")) {
    parseCsq(line);
    return;
  }

  if (line.startsWith("+COPS:")) {
    parseOperator(line);
    return;
  }

  if (line.startsWith("+CREG:") ||
      line.startsWith("+CEREG:") ||
      line.startsWith("+CGREG:")) {
    parseRegistration(line);
    return;
  }

  if (line.indexOf("ERROR") >= 0) {
    _online = true;
  }
}

void Modem::parseClip(const String& line) {
  const int firstQuote = line.indexOf('"');
  if (firstQuote < 0) {
    return;
  }

  const int secondQuote = line.indexOf('"', firstQuote + 1);
  if (secondQuote <= firstQuote) {
    return;
  }

  _callerId = line.substring(firstQuote + 1, secondQuote);
  Serial.print("MODEM: caller ID = ");
  Serial.println(_callerId);
}

void Modem::parseCpin(const String& line) {
  const int colon = line.indexOf(':');
  if (colon < 0) {
    return;
  }

  _simStatus = line.substring(colon + 1);
  _simStatus.trim();
  _simReady = (_simStatus == "READY");
}

void Modem::parseCsq(const String& line) {
  const int colon = line.indexOf(':');
  const int comma = line.indexOf(',', colon + 1);
  if (colon < 0 || comma < 0) {
    return;
  }

  _rssi = line.substring(colon + 1, comma).toInt();
}

void Modem::parseOperator(const String& line) {
  const int firstQuote = line.indexOf('"');
  if (firstQuote >= 0) {
    const int secondQuote = line.indexOf('"', firstQuote + 1);
    if (secondQuote > firstQuote) {
      _operatorName = line.substring(firstQuote + 1, secondQuote);
      return;
    }
  }

  _operatorName = line;
}

void Modem::parseRegistration(const String& line) {
  const int colon = line.indexOf(':');
  if (colon < 0) {
    return;
  }

  String values = line.substring(colon + 1);
  values.trim();

  int status = -1;
  const int comma = values.indexOf(',');
  if (comma >= 0) {
    status = values.substring(comma + 1).toInt();
  } else {
    status = values.toInt();
  }

  switch (status) {
    case 0:
      _registrationText = "NOT REGISTERED";
      _registered = false;
      break;
    case 1:
      _registrationText = "HOME";
      _registered = true;
      break;
    case 2:
      _registrationText = "SEARCHING";
      _registered = false;
      break;
    case 3:
      _registrationText = "DENIED";
      _registered = false;
      break;
    case 4:
      _registrationText = "UNKNOWN";
      _registered = false;
      break;
    case 5:
      _registrationText = "ROAMING";
      _registered = true;
      break;
    default:
      _registrationText = "UNRECOGNIZED";
      _registered = false;
      break;
  }
}

void Modem::setIncomingCall(bool active) {
  if (active == _incomingCall) {
    return;
  }

  _incomingCall = active;

  if (active) {
    _incomingStartedEvent = true;
    _incomingEndedEvent = false;
  } else {
    _incomingEndedEvent = true;
    _incomingStartedEvent = false;
    _lastRingAt = 0;
  }
}

void Modem::answerIncomingCall() {
  if (!_incomingCall) {
    Serial.println("MODEM: answer ignored; no incoming call");
    return;
  }

  // Reassert the board-specific audio path before every answered call.
  // This is intentionally repeated even though it is also configured at boot.
  configureVoiceAudio();

  _callResultEvent = CallResult::NONE;
  Serial.println("MODEM: answering incoming call (ATA)");
  sendRaw("ATA");
  _incomingCall = false;
  _incomingStartedEvent = false;
  _incomingEndedEvent = false;
  _lastRingAt = 0;
  _callActive = true;
}


void Modem::dialOutgoingCall(const String& number) {
  if (number.length() == 0) {
    Serial.println("MODEM: dial ignored; empty number");
    return;
  }

  configureVoiceAudio();

  _callResultEvent = CallResult::NONE;
  Serial.print("MODEM: dialing ");
  Serial.println(number);
  sendRaw("ATD" + number + ";");
  _callActive = true;
  _incomingCall = false;
  _incomingStartedEvent = false;
  _incomingEndedEvent = false;
  _lastRingAt = 0;
}

void Modem::hangUp() {
  if (!_callActive && !_incomingCall) {
    return;
  }

  Serial.println("MODEM: hanging up (AT+CHUP)");
  sendRaw("AT+CHUP");
  _callActive = false;
  setIncomingCall(false);
}

void Modem::requestStatus() {
  if (!_online) {
    Serial.println("MODEM: status request sent despite offline state");
  }

  sendRaw("AT+CPIN?");
  sendRaw("AT+CSQ");
  sendRaw("AT+COPS?");
  sendRaw("AT+CREG?");
  sendRaw("AT+CEREG?");
}

void Modem::sendRaw(const String& command) {
  if (command.length() == 0) {
    return;
  }

  _serial.print(command);
  _serial.print("\r\n");
}

bool Modem::isOnline() const {
  return _online;
}

bool Modem::simReady() const {
  return _simReady;
}

bool Modem::isRegistered() const {
  return _registered;
}

bool Modem::isIncomingCall() const {
  return _incomingCall;
}

bool Modem::isCallActive() const {
  return _callActive;
}

bool Modem::ringIndicatorActive() const {
  // RI is normally active low on SIMCom modules.
  return digitalRead(PIN_MODEM_RING) == LOW;
}

int Modem::rssi() const {
  return _rssi;
}

const String& Modem::operatorName() const {
  return _operatorName;
}

const String& Modem::callerId() const {
  return _callerId;
}

const String& Modem::simStatus() const {
  return _simStatus;
}

const String& Modem::registrationText() const {
  return _registrationText;
}

bool Modem::takeIncomingCallStarted() {
  const bool value = _incomingStartedEvent;
  _incomingStartedEvent = false;
  return value;
}

bool Modem::takeIncomingCallEnded() {
  const bool value = _incomingEndedEvent;
  _incomingEndedEvent = false;
  return value;
}


bool Modem::takeCallResult(CallResult& result) {
  if (_callResultEvent == CallResult::NONE) {
    return false;
  }

  result = _callResultEvent;
  _callResultEvent = CallResult::NONE;
  return true;
}

const char* Modem::callResultName(CallResult result) {
  switch (result) {
    case CallResult::NO_CARRIER:  return "NO CARRIER";
    case CallResult::BUSY:        return "BUSY";
    case CallResult::NO_ANSWER:   return "NO ANSWER";
    case CallResult::NO_DIALTONE: return "NO DIALTONE";
    default:                      return "NONE";
  }
}
