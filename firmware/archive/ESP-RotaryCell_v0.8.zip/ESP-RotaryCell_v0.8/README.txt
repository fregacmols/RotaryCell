ESP-RotaryCell v0.8
===================

PURPOSE
-------
v0.8 builds on the working v0.7.1 outgoing rotary dialing and v0.6 incoming
call/audio support. It focuses on call-state robustness and dialing safety.

NEW IN v0.8
-----------
- Keeps the 6-second number-complete timeout that tested successfully.
- Adds explicit phone-state reporting to USB serial:
    STATE: IDLE
    STATE: INCOMING
    STATE: DIAL TONE
    STATE: COLLECTING DIGITS
    STATE: OUTGOING
    STATE: CONNECTED
- Handles modem call-result messages BUSY, NO ANSWER, NO CARRIER, and
  NO DIALTONE and returns cleanly to a ready state.
- Replacing the handset cancels an outgoing attempt immediately with AT+CHUP.
- If an incoming caller disconnects before pickup, physical ringing stops.
- Adds a local dialing safety check BEFORE any ATD command is sent:
    * exact 911 is blocked
    * 900... and 1900... premium-rate prefixes are blocked
    * numbers shorter than 7 digits are treated as incomplete and blocked
- A blocked number is never passed to the A7670 modem. The serial console
  explains the reason, for example:
    SAFETY: BLOCKED emergency number 911
    DIAL: call not placed
- The deny rules are centralized in isBlockedNumber() in the main .ino file
  so additional prefixes/numbers can be added easily.

DIALING
-------
Lift handset -> dial-tone state -> rotary pulses are decoded -> digits are
printed and accumulated. Six seconds after the last digit, the firmware checks
the number against the local safety rules. Only an allowed number is sent as:

    ATD<number>;

GPIO36 DIAL-TONE HARDWARE (OPTIONAL / NOT YET WIRED IN CURRENT TEST UNIT)
------------------------------------------------------------------------
GPIO36 (DT_OUT) -> R5 3.3 k -> FILTER node
FILTER node -> C5 22 nF -> GND
FILTER node -> C6 220 nF series -> R6 10 k -> RX_SUM
RX_SUM is the receive-audio summing point feeding VR1 / Ag1171 VIN.

The firmware generates 350 Hz + 440 Hz on GPIO36, but no tone will be heard
until this passive injection network is installed.

CONNECTIONS
-----------
GPIO15 -> Ag1171 F/R
GPIO16 -> Ag1171 RM
GPIO37 <- Ag1171 SHK
GPIO36 -> dial-tone filter/injection network
GPIO5  <- modem TX
GPIO4  -> modem RX
GPIO6  <- modem RI
GPIO7  -> modem DTR
GPIO46 -> modem PWRKEY
GPIO42 -> modem power capability control
GPIO8  <- battery voltage divider

AUDIO CONNECTIONS
-----------------
Receive: LilyGO SPEK+/SPEK- -> isolated receive transformer -> RX_SUM -> VR1
         -> Ag1171 VIN
Dial tone: GPIO36 -> R5/C5/C6/R6 -> RX_SUM
Transmit: Ag1171 VOUT -> isolated transmit transformer -> LilyGO MIC+/MIC-

Do not ground either LilyGO SPEK or MIC conductor on the modem side of the
transformers.

SAFETY TESTS TO TRY
-------------------
1. Dial 911. Verify serial shows BLOCKED and no ATD911; is sent.
2. Dial a 900/1-900 number. Verify it is blocked locally.
3. Dial fewer than 7 digits. Verify it is rejected as incomplete.
4. Dial a normal test number. Verify exact accumulated digits are printed,
   then ATD is sent only after the 6-second timeout.
5. Hang up while the outgoing call is still ringing. Verify AT+CHUP.
6. Call the rotary and hang up before answering. Verify physical ringing stops.
7. Test BUSY / NO ANSWER / NO CARRIER behavior where practical.

KNOWN LIMITATIONS / TEST NOTES
------------------------------
- Dial-tone analog values are proposed and have not yet been bench validated.
- Receive audio remains somewhat low and will be optimized separately.
- The firmware treats ATD as an outgoing-call state immediately; modem result
  messages terminate that state.
- DIAL_MIN_DIGITS is 7 in Config.h. Change this if short-code dialing is ever
  intentionally required.
