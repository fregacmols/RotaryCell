#include "Console.h"
#include "Config.h"
#include "PhoneLine.h"
#include "RingGenerator.h"
#include "BatteryMonitor.h"
#include "Modem.h"

Console::Console(PhoneLine& phoneLine,
                 RingGenerator& ringGenerator,
                 BatteryMonitor& batteryMonitor,
                 Modem& modem)
  : _phoneLine(phoneLine),
    _ringGenerator(ringGenerator),
    _batteryMonitor(batteryMonitor),
    _modem(modem) {}

void Console::begin() {
  Serial.println();
  Serial.println("ESP-RotaryCell v0.8");
  Serial.println("Robust incoming/outgoing rotary firmware with dialing safety");
  printHelp();
}

void Console::update() {
  while (Serial.available()) {
    const char incoming = static_cast<char>(Serial.read());

    if (incoming == '\r' || incoming == '\n') {
      if (_inputBuffer.length() == 0) {
        continue;
      }

      String line = _inputBuffer;
      _inputBuffer = "";
      line.trim();

      if (_atTerminalMode) {
        handleATLine(line);
      } else {
        handleNormalLine(line);
      }
      continue;
    }

    if (_inputBuffer.length() < 160) {
      _inputBuffer += incoming;
    }
  }
}

void Console::handleNormalLine(String line) {
  line.trim();
  line.toUpperCase();

  if (line.length() == 0) {
    return;
  }

  const char command = line.charAt(0);

  switch (command) {
    case '?':
      printHelp();
      break;

    case 'S':
      printStatus();
      break;

    case 'M':
      _modem.requestStatus();
      printModemStatus();
      break;

    case 'A':
      _atTerminalMode = true;
      Serial.println();
      Serial.println("AT TERMINAL MODE");
      Serial.println("Enter AT commands normally. Enter EXIT to return.");
      break;

    case 'W':
      _modem.pulsePowerKey();
      Serial.println("MODEM: wait several seconds, then use M");
      break;

    case 'P':
      _phoneLine.setVerbosePulses(!_phoneLine.verbosePulses());
      Serial.print("VERBOSE PULSE MODE: ");
      Serial.println(_phoneLine.verbosePulses() ? "ON" : "OFF");
      break;

    case 'R':
      if (_phoneLine.isOffHook()) {
        Serial.println("RING REFUSED: replace handset first");
      } else {
        _ringGenerator.startTest();
      }
      break;

    case 'C':
      if (_phoneLine.isOffHook()) {
        Serial.println("RING REFUSED: replace handset first");
      } else {
        _ringGenerator.startCadence();
      }
      break;

    case 'X':
      _ringGenerator.stop();
      Serial.println("RING: stopped");
      break;

    default:
      Serial.print("UNKNOWN COMMAND: ");
      Serial.println(line);
      Serial.println("Type ? for help.");
      break;
  }
}

void Console::handleATLine(String line) {
  if (line.equalsIgnoreCase("EXIT")) {
    _atTerminalMode = false;
    Serial.println("AT terminal closed");
    return;
  }

  Serial.print("[AT>] ");
  Serial.println(line);
  _modem.sendRaw(line);
}

void Console::printHelp() const {
  Serial.println();
  Serial.println("Commands (press Send after each command):");
  Serial.println("  ?  Help");
  Serial.println("  S  Complete status");
  Serial.println("  M  Refresh and display modem status");
  Serial.println("  A  Enter AT terminal mode; type EXIT to leave");
  Serial.println("  W  Pulse modem PWRKEY if it is not responding");
  Serial.println("  P  Toggle verbose rotary-pulse display");
  Serial.println("  R  One-second ring test");
  Serial.println("  C  One complete manual ring cadence");
  Serial.println("  X  Stop physical ringing");
  Serial.println();
}

void Console::printStatus() const {
  Serial.println();
  Serial.println("--- ESP-RotaryCell status ---");

  Serial.print("Handset: ");
  Serial.println(_phoneLine.isOffHook() ? "OFF HOOK" : "ON HOOK");

  Serial.print("Pending dial pulses: ");
  Serial.println(_phoneLine.pendingPulseCount());

  Serial.print("Ring generator: ");
  Serial.println(_ringGenerator.modeName());

  Serial.print("Battery: ");
  if (_batteryMonitor.readingValid()) {
    Serial.print(_batteryMonitor.volts(), 3);
    Serial.print(" V (approximately ");
    Serial.print(_batteryMonitor.estimatedPercent());
    Serial.println("%)");
  } else {
    Serial.print("reading unavailable (");
    Serial.print(_batteryMonitor.millivolts());
    Serial.println(" mV)");
  }

  printModemStatus();
  Serial.println("-----------------------------");
  Serial.println();
}

void Console::printModemStatus() const {
  Serial.println();
  Serial.println("Modem:");

  Serial.print("  UART response: ");
  Serial.println(_modem.isOnline() ? "ONLINE" : "NO RESPONSE");

  Serial.print("  SIM: ");
  Serial.println(_modem.simStatus());

  Serial.print("  Registration: ");
  Serial.println(_modem.registrationText());

  Serial.print("  Operator: ");
  Serial.println(_modem.operatorName().length() > 0
                   ? _modem.operatorName()
                   : String("UNKNOWN"));

  Serial.print("  CSQ RSSI: ");
  if (_modem.rssi() < 0 || _modem.rssi() == 99) {
    Serial.println("UNKNOWN");
  } else {
    Serial.print(_modem.rssi());
    Serial.println(" / 31");
  }

  Serial.print("  Incoming call: ");
  Serial.println(_modem.isIncomingCall() ? "YES" : "NO");

  Serial.print("  Cellular call active: ");
  Serial.println(_modem.isCallActive() ? "YES" : "NO");

  Serial.print("  Caller ID: ");
  Serial.println(_modem.callerId().length() > 0
                   ? _modem.callerId()
                   : String("UNKNOWN"));

  Serial.print("  Hardware RI pin: ");
  Serial.println(_modem.ringIndicatorActive() ? "ACTIVE" : "INACTIVE");
}
