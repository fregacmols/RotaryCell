#include "Config.h"
#include "PhoneLine.h"
#include "RingGenerator.h"
#include "BatteryMonitor.h"
#include "Modem.h"
#include "Console.h"
#include "DialToneGenerator.h"

PhoneLine phoneLine;
RingGenerator ringGenerator;
BatteryMonitor batteryMonitor;
Modem modem;
Console console(phoneLine, ringGenerator, batteryMonitor, modem);
DialToneGenerator dialTone;

bool previousOffHook = false;
String dialedNumber;
uint32_t lastDigitAt = 0;

enum class PhoneState {
  IDLE,
  INCOMING,
  DIAL_TONE,
  COLLECTING,
  OUTGOING,
  CONNECTED
};

PhoneState phoneState = PhoneState::IDLE;

const char* phoneStateName(PhoneState state) {
  switch (state) {
    case PhoneState::IDLE:       return "IDLE";
    case PhoneState::INCOMING:   return "INCOMING";
    case PhoneState::DIAL_TONE:  return "DIAL TONE";
    case PhoneState::COLLECTING: return "COLLECTING DIGITS";
    case PhoneState::OUTGOING:   return "OUTGOING";
    case PhoneState::CONNECTED:  return "CONNECTED";
    default:                     return "UNKNOWN";
  }
}

void setPhoneState(PhoneState state) {
  if (state == phoneState) {
    return;
  }
  phoneState = state;
  Serial.print("STATE: ");
  Serial.println(phoneStateName(phoneState));
}

bool isBlockedNumber(const String& number, String& reason) {
  if (number == "911") {
    reason = "emergency number 911";
    return true;
  }

  // North-American premium-rate 900 service, with or without leading 1.
  if (number.startsWith("900") || number.startsWith("1900")) {
    reason = "premium-rate 900 number";
    return true;
  }

  if (number.length() < DIAL_MIN_DIGITS) {
    reason = "incomplete/short number";
    return true;
  }

  return false;
}

void clearDialing() {
  dialTone.stop();
  dialedNumber = "";
  lastDigitAt = 0;
}

void setup() {
  Serial.begin(SERIAL_BAUD);
  delay(750);

  phoneLine.begin();
  ringGenerator.begin();
  batteryMonitor.begin();
  modem.begin();
  dialTone.begin();
  console.begin();

  previousOffHook = phoneLine.isOffHook();
  Serial.print("STATE: ");
  Serial.println(phoneStateName(phoneState));
}

void loop() {
  phoneLine.update();
  ringGenerator.update();
  batteryMonitor.update();
  modem.update();
  console.update();

  // A new cellular call starts the physical bell only while on hook.
  if (modem.takeIncomingCallStarted()) {
    Serial.println();
    Serial.println("CELLULAR: incoming call");
    setPhoneState(PhoneState::INCOMING);

    clearDialing();

    if (modem.callerId().length() > 0) {
      Serial.print("CALLER ID: ");
      Serial.println(modem.callerId());
    }

    if (phoneLine.isOffHook()) {
      Serial.println("CELLULAR: handset already off hook; answering");
      modem.answerIncomingCall();
      setPhoneState(PhoneState::CONNECTED);
    } else {
      ringGenerator.startIncomingCadence();
    }
  }

  // Stop the physical bell when the remote caller disconnects.
  if (modem.takeIncomingCallEnded()) {
    if (ringGenerator.isIncomingCadence()) {
      ringGenerator.stop();
    }
    Serial.println("CELLULAR: call ended");
    if (!phoneLine.isOffHook()) {
      setPhoneState(PhoneState::IDLE);
    }
  }

  const bool offHook = phoneLine.isOffHook();

  // React only to a genuine handset pickup, not to dial-pulse breaks.
  if (offHook && !previousOffHook) {
    if (ringGenerator.isActive()) {
      ringGenerator.stop();
      Serial.println("RING: stopped because handset went off hook");
    }

    if (modem.isIncomingCall()) {
      modem.answerIncomingCall();
      Serial.println("CELLULAR: call answered; voice audio enabled");
      setPhoneState(PhoneState::CONNECTED);
    } else if (!modem.isCallActive()) {
      dialedNumber = "";
      lastDigitAt = 0;
      dialTone.start();
      Serial.println("DIAL: ready");
      setPhoneState(PhoneState::DIAL_TONE);
    }
  }

  // The first recognized rotary pulse silences dial tone immediately.
  if (dialTone.isActive() && phoneLine.pendingPulseCount() > 0) {
    dialTone.stop();
    setPhoneState(PhoneState::COLLECTING);
  }

  // Consume completed rotary digits and build the outgoing number.
  uint8_t digit = 0;
  if (phoneLine.takeCompletedDigit(digit)) {
    if (offHook && !modem.isIncomingCall() && !modem.isCallActive()) {
      dialTone.stop();

      if (dialedNumber.length() < DIAL_MAX_DIGITS) {
        dialedNumber += static_cast<char>('0' + digit);
        lastDigitAt = millis();
        setPhoneState(PhoneState::COLLECTING);

        Serial.print("DIAL: digit = ");
        Serial.println(digit);
        Serial.print("DIAL: number = ");
        Serial.println(dialedNumber);
      } else {
        Serial.println("DIAL: maximum number length reached; digit ignored");
      }
    }
  }

  // Six seconds with no new digit means the number is complete.
  if (offHook &&
      !modem.isIncomingCall() &&
      !modem.isCallActive() &&
      dialedNumber.length() > 0 &&
      lastDigitAt > 0 &&
      millis() - lastDigitAt >= DIAL_NUMBER_TIMEOUT_MS) {
    const String numberToDial = dialedNumber;
    dialedNumber = "";
    lastDigitAt = 0;

    Serial.println("DIAL: number complete after 6.0 s");
    Serial.print("DIAL: complete -> ");
    Serial.println(numberToDial);

    String blockReason;
    if (isBlockedNumber(numberToDial, blockReason)) {
      Serial.print("SAFETY: BLOCKED ");
      Serial.println(blockReason);
      Serial.println("DIAL: call not placed");
      // Stay off hook but return to a fresh dialing state. Dial tone may be
      // added physically later; the firmware output remains available.
      dialTone.start();
      setPhoneState(PhoneState::DIAL_TONE);
    } else {
      Serial.print("MODEM: ATD");
      Serial.print(numberToDial);
      Serial.println(";");
      modem.dialOutgoingCall(numberToDial);
      setPhoneState(PhoneState::OUTGOING);
    }
  }

  // Hanging up ends an active cellular call or abandons an unfinished number.
  if (!offHook && previousOffHook) {
    clearDialing();

    if (modem.isCallActive() || modem.isIncomingCall()) {
      modem.hangUp();
      Serial.println("CELLULAR: call ended/cancelled because handset went on hook");
    } else {
      Serial.println("DIAL: cancelled; handset on hook");
    }
    setPhoneState(PhoneState::IDLE);
  }

  Modem::CallResult callResult;
  if (modem.takeCallResult(callResult)) {
    Serial.print("CALL RESULT: ");
    Serial.println(Modem::callResultName(callResult));

    if (ringGenerator.isActive()) {
      ringGenerator.stop();
    }

    if (offHook) {
      clearDialing();
      // Leave the handset off hook and make it ready for another attempt.
      dialTone.start();
      setPhoneState(PhoneState::DIAL_TONE);
    } else {
      setPhoneState(PhoneState::IDLE);
    }
  }

  previousOffHook = offHook;
}
