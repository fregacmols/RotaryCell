#include "HookSwitch.h"
#include "Config.h"
#include <Arduino.h>
void HookSwitch::begin(){pinMode(PIN_SHK,INPUT_PULLUP);last=!digitalRead(PIN_SHK);off=last;}
void HookSwitch::update(){bool r=!digitalRead(PIN_SHK);if(r!=last){last=r;t=millis();}if((millis()-t)>HOOK_DEBOUNCE_MS&&r!=off){off=r;Serial.println(off?"HANDSET: OFF HOOK":"HANDSET: ON HOOK");}}
