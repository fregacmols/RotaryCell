#include "RingGenerator.h"
#include "Config.h"
#include <Arduino.h>
void RingGenerator::begin(){pinMode(PIN_FR,OUTPUT);pinMode(PIN_RM,OUTPUT);digitalWrite(PIN_FR,LOW);digitalWrite(PIN_RM,LOW);}void RingGenerator::update(){}
