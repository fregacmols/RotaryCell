Initial skeleton for ESP-RotaryCell. Next revision will implement console command dispatch, ring control, and rotary decoding.
