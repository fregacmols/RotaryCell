#include "Config.h"
#include "Console.h"
#include "HookSwitch.h"
#include "RingGenerator.h"

Console console; HookSwitch hook; RingGenerator ring;
void setup(){console.begin();hook.begin();ring.begin();}
void loop(){console.update();hook.update();ring.update();}
