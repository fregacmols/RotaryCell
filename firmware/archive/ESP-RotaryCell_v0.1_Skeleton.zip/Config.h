#pragma once
#include <Arduino.h>
constexpr uint8_t PIN_FR=15,PIN_RM=16,PIN_SHK=37; constexpr uint16_t RING_HALF_PERIOD_MS=25,RING_TEST_MS=1000,HOOK_DEBOUNCE_MS=25;
