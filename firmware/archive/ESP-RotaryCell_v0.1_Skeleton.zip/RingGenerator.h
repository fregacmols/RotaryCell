#pragma once
class RingGenerator{public:void begin();void update();};
