#include "Console.h"
#include <Arduino.h>
void Console::begin(){Serial.begin(115200);delay(500);Serial.println("\nESP-RotaryCell v0.1");Serial.println("Type ? for help.");}
void Console::update(){if(!Serial.available())return;char c=toupper(Serial.read());switch(c){case '?':Serial.println("? Help\nS Status\nR Ring test");break;case 'S':Serial.println("Status stub");break;case 'R':Serial.println("Ring stub");break;}}
