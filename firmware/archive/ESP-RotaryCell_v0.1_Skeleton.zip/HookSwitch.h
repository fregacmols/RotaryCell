#pragma once
class HookSwitch{public:void begin();void update();private:bool off=false,last=false;unsigned long t=0;};
