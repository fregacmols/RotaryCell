ESP-RotaryCell v0.3
===================

NEW IN v0.3
-----------
- Battery voltage monitoring using the LilyGO T-A7670G-S3 Standard's
  onboard battery divider on GPIO8.
- Approximate Li-ion state-of-charge percentage in the S status display.
- Eight-sample ADC averaging, refreshed every five seconds.

EXISTING FEATURES
-----------------
- Handset on-hook/off-hook detection
- Rotary digit decoding through Ag1171 SHK
- Optional pulse timing diagnostics
- One-second ring test
- One complete 2-second-on / 4-second-off ring cadence
- Automatic ring shutdown when the handset is lifted

ARDUINO IDE SETTINGS
--------------------
Board: ESP32S3 Dev Module
USB CDC On Boot: Enabled
Serial Monitor: 115200 baud

IMPORTANT:
Arduino IDE may silently return USB CDC On Boot to Disabled. If upload
succeeds but Serial Monitor is blank, check that setting first.

CONNECTIONS
-----------
GPIO15 -> Ag1171 F/R
GPIO16 -> Ag1171 RM
GPIO37 <- Ag1171 SHK
GPIO8  <- onboard battery voltage divider (already wired by LilyGO)

COMMANDS
--------
? = help
S = status, including battery voltage and approximate percentage
P = toggle individual rotary-pulse timing output
R = one-second ring test
C = one complete ring cadence
X = stop ringing

BATTERY READING NOTES
---------------------
The battery voltage comes from the board's built-in resistor divider.
No external wiring is required.

The displayed percentage is only an estimate. It can read lower during
cellular transmission or ringing and higher while USB charging is active.
Voltage is the more trustworthy value.

MODEM SUPPORT
-------------
This version does not initialize or control the A7670G modem. Modem
bring-up is planned for the next development stage.
