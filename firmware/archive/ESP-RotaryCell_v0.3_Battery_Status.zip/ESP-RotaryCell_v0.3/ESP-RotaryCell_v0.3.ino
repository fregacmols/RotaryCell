#include "Config.h"
#include "PhoneLine.h"
#include "RingGenerator.h"
#include "BatteryMonitor.h"
#include "Console.h"

PhoneLine phoneLine;
RingGenerator ringGenerator;
BatteryMonitor batteryMonitor;
Console console(phoneLine, ringGenerator, batteryMonitor);

void setup() {
  Serial.begin(SERIAL_BAUD);
  delay(750);

  phoneLine.begin();
  ringGenerator.begin();
  batteryMonitor.begin();
  console.begin();
}

void loop() {
  phoneLine.update();
  ringGenerator.update();
  batteryMonitor.update();
  console.update();

  // Never continue ringing after the handset is lifted.
  if (phoneLine.isOffHook() && ringGenerator.isActive()) {
    ringGenerator.stop();
    Serial.println("RING: stopped because handset went off hook");
  }
}
