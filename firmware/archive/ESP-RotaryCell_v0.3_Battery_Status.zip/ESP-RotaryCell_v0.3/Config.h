#pragma once
#include <Arduino.h>

// Ag1171 connections
constexpr uint8_t PIN_FR  = 15;  // Forward/Reverse
constexpr uint8_t PIN_RM  = 16;  // Ring Mode
constexpr uint8_t PIN_SHK = 37;  // Switch Hook output

// LilyGO T-A7670G-S3 Standard battery monitor
constexpr uint8_t PIN_BATTERY_ADC = 8;
constexpr uint8_t BATTERY_DIVIDER_RATIO = 2;
constexpr uint8_t BATTERY_SAMPLE_COUNT = 8;
constexpr uint32_t BATTERY_SAMPLE_INTERVAL_MS = 5000;
constexpr uint16_t BATTERY_VALID_MIN_MV = 2500;
constexpr uint16_t BATTERY_VALID_MAX_MV = 4500;

// Your Ag1171 hardware reports HIGH while the handset is off hook.
constexpr bool SHK_ACTIVE_HIGH = true;

// USB serial console
constexpr uint32_t SERIAL_BAUD = 115200;

// Phone-line timing
constexpr uint16_t SHK_DEBOUNCE_MS       = 8;
constexpr uint16_t DIAL_PULSE_MIN_MS     = 25;
constexpr uint16_t DIAL_PULSE_MAX_MS     = 140;
constexpr uint16_t DIGIT_COMPLETE_MS     = 250;
constexpr uint16_t HANGUP_CONFIRM_MS     = 500;

// Ringing
constexpr uint16_t RING_HALF_PERIOD_MS   = 25;    // 20 Hz complete cycle
constexpr uint32_t RING_TEST_DURATION_MS = 1000;
constexpr uint32_t CADENCE_RING_ON_MS    = 2000;
constexpr uint32_t CADENCE_RING_OFF_MS   = 4000;
