#include "RingGenerator.h"
#include "Config.h"

void RingGenerator::begin() {
  pinMode(PIN_FR, OUTPUT);
  pinMode(PIN_RM, OUTPUT);
  endRingOutput();
}

void RingGenerator::startTest() {
  stop();
  _mode = Mode::Test;
  _modeStartedAt = millis();
  beginRingOutput();
  Serial.println("RING: one-second test started");
}

void RingGenerator::startCadence() {
  stop();
  _mode = Mode::CadenceRing;
  _modeStartedAt = millis();
  beginRingOutput();
  Serial.println("RING: cadence started (2 seconds on, 4 seconds off)");
}

void RingGenerator::stop() {
  endRingOutput();
  _mode = Mode::Idle;
}

void RingGenerator::update() {
  const uint32_t now = millis();
  switch (_mode) {
    case Mode::Idle:
      return;
    case Mode::Test:
      updateRingWave(now);
      if (now - _modeStartedAt >= RING_TEST_DURATION_MS) {
        stop();
        Serial.println("RING: test complete");
      }
      return;
    case Mode::CadenceRing:
      updateRingWave(now);
      if (now - _modeStartedAt >= CADENCE_RING_ON_MS) {
        endRingOutput();
        _mode = Mode::CadencePause;
        _modeStartedAt = now;
        Serial.println("RING: cadence pause");
      }
      return;
    case Mode::CadencePause:
      if (now - _modeStartedAt >= CADENCE_RING_OFF_MS) {
        stop();
        Serial.println("RING: cadence complete");
      }
      return;
  }
}

void RingGenerator::beginRingOutput() {
  _phase = false;
  _lastToggleAt = millis();
  digitalWrite(PIN_FR, LOW);
  digitalWrite(PIN_RM, HIGH);
}

void RingGenerator::endRingOutput() {
  digitalWrite(PIN_RM, LOW);
  digitalWrite(PIN_FR, LOW);
  _phase = false;
}

void RingGenerator::updateRingWave(uint32_t now) {
  if (now - _lastToggleAt >= RING_HALF_PERIOD_MS) {
    _lastToggleAt = now;
    _phase = !_phase;
    digitalWrite(PIN_FR, _phase ? HIGH : LOW);
  }
}

bool RingGenerator::isActive() const { return _mode != Mode::Idle; }
const char* RingGenerator::modeName() const {
  switch (_mode) {
    case Mode::Idle: return "IDLE";
    case Mode::Test: return "TEST";
    case Mode::CadenceRing: return "CADENCE RING";
    case Mode::CadencePause: return "CADENCE PAUSE";
  }
  return "UNKNOWN";
}
