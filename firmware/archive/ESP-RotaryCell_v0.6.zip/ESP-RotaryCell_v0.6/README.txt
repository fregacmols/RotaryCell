ESP-RotaryCell v0.6
===================

PURPOSE
-------
v0.6 enables the tested LilyGO T-A7670G-S3 Standard analog voice-audio path
while preserving the incoming-call ringing, answer, and hang-up behavior from
v0.5.1. Outgoing rotary dialing is deliberately deferred to the next revision.

NEW IN v0.6
-----------
- Enables the LilyGO onboard speaker power amplifier at modem initialization:
    AT+CGDRT=3,1
    AT+CGSETV=3,1
- Selects speaker audio path and tested receive gain:
    AT+CSDVC=3
    AT+COUTGAIN=7
- Reasserts all four voice-audio settings immediately before every ATA answer
- Updated console text to reflect that two-way voice audio is now connected
- Retains v0.5.1 incoming ringing, ATA answer, AT+CHUP hang-up, diagnostics,
  battery monitor, rotary pulse monitoring, and AT terminal

CONNECTIONS
-----------
GPIO15 -> Ag1171 F/R
GPIO16 -> Ag1171 RM
GPIO37 <- Ag1171 SHK
GPIO5  <- modem TX
GPIO4  -> modem RX
GPIO6  <- modem RI
GPIO7  -> modem DTR
GPIO46 -> modem PWRKEY
GPIO42 -> modem power capability control
GPIO8  <- battery voltage divider

AUDIO CONNECTIONS
-----------------
Receive: LilyGO SPEK+/SPEK- -> isolated receive transformer -> Ag1171 VIN
Transmit: Ag1171 VOUT -> isolated transmit transformer -> LilyGO MIC+/MIC-
Do not ground either LilyGO SPEK or MIC conductor on the modem side of the
transformers.

EXPECTED INCOMING-CALL TEST
---------------------------
1. Leave the Model 500 on hook.
2. Call the SIM number.
3. The mechanical bell should ring in a 2-second-on/4-second-off cadence.
4. Lift the handset. The firmware stops the bell, reasserts the audio-amplifier
   configuration, and sends ATA.
5. Verify two-way voice audio.
6. Replace the handset. The firmware sends AT+CHUP.
7. Repeat the call to verify audio remains available on subsequent calls.

COMMANDS
--------
? = help
S = complete status
M = manually refresh and display modem status
A = AT terminal mode; enter EXIT to leave
W = pulse modem PWRKEY
P = toggle rotary-pulse timing output
R = one-second ring test
C = one complete manual cadence
X = stop physical ringing

KNOWN LIMITATIONS
-----------------
- Receive and transmit audio levels still require final analog adjustment.
- No outgoing dialing yet.
- Call-active state is set when ATA is sent and cleared on AT+CHUP or a terminal
  modem result such as NO CARRIER.
