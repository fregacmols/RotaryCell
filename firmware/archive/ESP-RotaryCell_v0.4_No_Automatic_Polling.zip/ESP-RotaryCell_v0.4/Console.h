#pragma once
#include <Arduino.h>

class PhoneLine;
class RingGenerator;
class BatteryMonitor;
class Modem;

class Console {
public:
  Console(PhoneLine& phoneLine,
          RingGenerator& ringGenerator,
          BatteryMonitor& batteryMonitor,
          Modem& modem);

  void begin();
  void update();

private:
  void printHelp() const;
  void printStatus() const;
  void printModemStatus() const;
  void handleNormalLine(String line);
  void handleATLine(String line);

  PhoneLine& _phoneLine;
  RingGenerator& _ringGenerator;
  BatteryMonitor& _batteryMonitor;
  Modem& _modem;

  String _inputBuffer;
  bool _atTerminalMode = false;
};
