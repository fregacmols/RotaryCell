#include "Config.h"
#include "PhoneLine.h"
#include "RingGenerator.h"
#include "BatteryMonitor.h"
#include "Modem.h"
#include "Console.h"

PhoneLine phoneLine;
RingGenerator ringGenerator;
BatteryMonitor batteryMonitor;
Modem modem;
Console console(phoneLine, ringGenerator, batteryMonitor, modem);

void setup() {
  Serial.begin(SERIAL_BAUD);
  delay(750);

  phoneLine.begin();
  ringGenerator.begin();
  batteryMonitor.begin();
  modem.begin();
  console.begin();
}

void loop() {
  phoneLine.update();
  ringGenerator.update();
  batteryMonitor.update();
  modem.update();
  console.update();

  // A new cellular call starts the physical bell only while on hook.
  if (modem.takeIncomingCallStarted()) {
    Serial.println();
    Serial.println("CELLULAR: incoming call");

    if (modem.callerId().length() > 0) {
      Serial.print("CALLER ID: ");
      Serial.println(modem.callerId());
    }

    if (phoneLine.isOffHook()) {
      Serial.println("RING: not started because handset is already off hook");
    } else {
      ringGenerator.startIncomingCadence();
    }
  }

  // Stop the physical bell when the network call ends.
  if (modem.takeIncomingCallEnded()) {
    if (ringGenerator.isIncomingCadence()) {
      ringGenerator.stop();
    }
    Serial.println("CELLULAR: incoming call ended");
  }

  // v0.4 deliberately does not answer. Lifting the handset only silences
  // the bell; ATA and audio handling are planned for the next version.
  if (phoneLine.isOffHook() && ringGenerator.isActive()) {
    ringGenerator.stop();
    Serial.println("RING: stopped because handset went off hook");
    if (modem.isIncomingCall()) {
      Serial.println("NOTE: v0.4 has not answered the cellular call");
    }
  }
}
