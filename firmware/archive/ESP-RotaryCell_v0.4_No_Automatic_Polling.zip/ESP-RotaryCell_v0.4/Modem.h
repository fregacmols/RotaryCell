#pragma once
#include <Arduino.h>

class Modem {
public:
  void begin();
  void update();

  void requestStatus();
  void sendRaw(const String& command);
  void pulsePowerKey();

  bool isOnline() const;
  bool simReady() const;
  bool isRegistered() const;
  bool isIncomingCall() const;
  bool ringIndicatorActive() const;

  int rssi() const;
  const String& operatorName() const;
  const String& callerId() const;
  const String& simStatus() const;
  const String& registrationText() const;

  bool takeIncomingCallStarted();
  bool takeIncomingCallEnded();

private:
  bool waitForAT(uint32_t timeoutMs);
  void configureModem();
  void readSerial();
  void processLine(String line);
  void parseClip(const String& line);
  void parseCpin(const String& line);
  void parseCsq(const String& line);
  void parseOperator(const String& line);
  void parseRegistration(const String& line);
  void setIncomingCall(bool active);

  HardwareSerial _serial{1};
  String _lineBuffer;

  bool _online = false;
  bool _simReady = false;
  bool _registered = false;
  bool _incomingCall = false;
  bool _incomingStartedEvent = false;
  bool _incomingEndedEvent = false;

  int _rssi = -1;
  String _operatorName;
  String _callerId;
  String _simStatus = "UNKNOWN";
  String _registrationText = "UNKNOWN";

  uint32_t _lastRingAt = 0;
  uint32_t _lastStatusRefreshAt = 0;
};
