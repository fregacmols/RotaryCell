ESP-RotaryCell v0.7
===================

PURPOSE
-------
v0.7 adds outgoing rotary dialing and a generated North-American dial tone to
v0.6 while preserving the working incoming-call ringing, answer, hang-up, and
voice-audio behavior.

NEW IN v0.7
-----------
- GPIO36 selected as the dial-tone output. On the LilyGO S3-Standard layout it
  is a camera data pin and is available because ESP-RotaryCell does not use the
  camera interface.
- Generates 350 Hz + 440 Hz dial tone with PWM on GPIO36.
- Dial tone starts when the handset is lifted while idle.
- Dial tone stops when rotary dialing begins.
- Completed rotary digits are queued to the main program and printed to USB:
    DIAL: digit = 9
    DIAL: number = 919
- After 3 seconds without another digit, firmware sends:
    ATD<number>;
- The LilyGO voice amplifier/audio path is reasserted before outgoing calls.
- Replacing the handset sends AT+CHUP for either incoming or outgoing calls.

DIAL-TONE HARDWARE ADDITION
-----------------------------
GPIO36 (DT_OUT) -> R5 3.3 k -> FILTER node
FILTER node -> C5 22 nF -> GND
FILTER node -> C6 220 nF series -> R6 10 k -> RX_SUM
RX_SUM is the receive-audio summing point feeding VR1 / Ag1171 VIN.

These are the Rev C proposed component values and still need bench validation.
Do not connect GPIO36 directly to Ag1171 VIN without the filter/coupling parts.

CONNECTIONS
-----------
GPIO15 -> Ag1171 F/R
GPIO16 -> Ag1171 RM
GPIO37 <- Ag1171 SHK
GPIO36 -> dial-tone filter/injection network
GPIO5  <- modem TX
GPIO4  -> modem RX
GPIO6  <- modem RI
GPIO7  -> modem DTR
GPIO46 -> modem PWRKEY
GPIO42 -> modem power capability control
GPIO8  <- battery voltage divider

AUDIO CONNECTIONS
-----------------
Receive: LilyGO SPEK+/SPEK- -> isolated receive transformer -> RX_SUM -> VR1
         -> Ag1171 VIN
Dial tone: GPIO36 -> R5/C5/C6/R6 -> RX_SUM
Transmit: Ag1171 VOUT -> isolated transmit transformer -> LilyGO MIC+/MIC-

Do not ground either LilyGO SPEK or MIC conductor on the modem side of the
transformers.

OUTGOING CALL TEST
------------------
1. Install the GPIO36 dial-tone injection components before expecting tone.
2. Leave the phone idle/on hook.
3. Lift the handset. A 350 + 440 Hz dial tone should be heard.
4. Dial a number on the rotary dial. Dial tone should stop after the first
   recognized pulse.
5. Watch USB serial. Each decoded digit and accumulated number are printed.
6. After 3 seconds without another digit, the firmware sends ATD<number>;.
7. Verify ringback/call audio.
8. Replace the handset. Firmware sends AT+CHUP.

INCOMING CALL TEST
------------------
Incoming calls retain v0.6 behavior: mechanical ringing, pickup -> ATA,
two-way audio, and handset replacement -> AT+CHUP.

COMMANDS
--------
? = help
S = complete status
M = manually refresh and display modem status
A = AT terminal mode; enter EXIT to leave
W = pulse modem PWRKEY
P = toggle rotary-pulse timing output
R = one-second ring test
C = one complete manual cadence
X = stop physical ringing

KNOWN LIMITATIONS / TEST NOTES
------------------------------
- Dial-tone analog values are proposed and have not yet been bench validated.
- Receive audio level remains somewhat low and will be optimized separately.
- Outgoing-call state is considered active when ATD is sent; modem terminal
  results such as NO CARRIER/BUSY/NO ANSWER clear it.
- Number-complete timeout is 3 seconds and can be changed in Config.h.
