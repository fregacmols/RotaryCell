#include "Config.h"
#include "PhoneLine.h"
#include "RingGenerator.h"
#include "BatteryMonitor.h"
#include "Modem.h"
#include "Console.h"
#include "DialToneGenerator.h"

PhoneLine phoneLine;
RingGenerator ringGenerator;
BatteryMonitor batteryMonitor;
Modem modem;
Console console(phoneLine, ringGenerator, batteryMonitor, modem);
DialToneGenerator dialTone;

bool previousOffHook = false;
String dialedNumber;
uint32_t lastDigitAt = 0;

void clearDialing() {
  dialTone.stop();
  dialedNumber = "";
  lastDigitAt = 0;
}

void setup() {
  Serial.begin(SERIAL_BAUD);
  delay(750);

  phoneLine.begin();
  ringGenerator.begin();
  batteryMonitor.begin();
  modem.begin();
  dialTone.begin();
  console.begin();

  previousOffHook = phoneLine.isOffHook();
}

void loop() {
  phoneLine.update();
  ringGenerator.update();
  batteryMonitor.update();
  modem.update();
  console.update();

  // A new cellular call starts the physical bell only while on hook.
  if (modem.takeIncomingCallStarted()) {
    Serial.println();
    Serial.println("CELLULAR: incoming call");

    clearDialing();

    if (modem.callerId().length() > 0) {
      Serial.print("CALLER ID: ");
      Serial.println(modem.callerId());
    }

    if (phoneLine.isOffHook()) {
      Serial.println("CELLULAR: handset already off hook; answering");
      modem.answerIncomingCall();
    } else {
      ringGenerator.startIncomingCadence();
    }
  }

  // Stop the physical bell when the remote caller disconnects.
  if (modem.takeIncomingCallEnded()) {
    if (ringGenerator.isIncomingCadence()) {
      ringGenerator.stop();
    }
    Serial.println("CELLULAR: call ended");
  }

  const bool offHook = phoneLine.isOffHook();

  // React only to a genuine handset pickup, not to dial-pulse breaks.
  if (offHook && !previousOffHook) {
    if (ringGenerator.isActive()) {
      ringGenerator.stop();
      Serial.println("RING: stopped because handset went off hook");
    }

    if (modem.isIncomingCall()) {
      modem.answerIncomingCall();
      Serial.println("CELLULAR: call answered; voice audio enabled");
    } else if (!modem.isCallActive()) {
      dialedNumber = "";
      lastDigitAt = 0;
      dialTone.start();
      Serial.println("DIAL: ready");
    }
  }

  // The first recognized rotary pulse silences dial tone immediately.
  if (dialTone.isActive() && phoneLine.pendingPulseCount() > 0) {
    dialTone.stop();
  }

  // Consume completed rotary digits and build the outgoing number.
  uint8_t digit = 0;
  if (phoneLine.takeCompletedDigit(digit)) {
    if (offHook && !modem.isIncomingCall() && !modem.isCallActive()) {
      dialTone.stop();

      if (dialedNumber.length() < DIAL_MAX_DIGITS) {
        dialedNumber += static_cast<char>('0' + digit);
        lastDigitAt = millis();

        Serial.print("DIAL: digit = ");
        Serial.println(digit);
        Serial.print("DIAL: number = ");
        Serial.println(dialedNumber);
      } else {
        Serial.println("DIAL: maximum number length reached; digit ignored");
      }
    }
  }

  // Three seconds with no new digit means the number is complete.
  if (offHook &&
      !modem.isIncomingCall() &&
      !modem.isCallActive() &&
      dialedNumber.length() > 0 &&
      lastDigitAt > 0 &&
      millis() - lastDigitAt >= DIAL_NUMBER_TIMEOUT_MS) {
    const String numberToDial = dialedNumber;
    dialedNumber = "";
    lastDigitAt = 0;

    Serial.print("DIAL: complete -> ");
    Serial.println(numberToDial);
    modem.dialOutgoingCall(numberToDial);
  }

  // Hanging up ends an active cellular call or abandons an unfinished number.
  if (!offHook && previousOffHook) {
    clearDialing();

    if (modem.isCallActive()) {
      modem.hangUp();
      Serial.println("CELLULAR: call ended because handset went on hook");
    } else {
      Serial.println("DIAL: cancelled; handset on hook");
    }
  }

  previousOffHook = offHook;
}
