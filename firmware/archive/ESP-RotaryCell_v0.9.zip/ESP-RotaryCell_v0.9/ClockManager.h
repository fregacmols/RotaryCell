#pragma once
#include <Arduino.h>
#include <time.h>

class ClockManager {
public:
  void begin();
  void setNetworkTime(time_t utcEpoch, int timezoneQuarterHours);
  bool isSynced() const;
  String timestamp() const;
  String displayTime() const;
  uint32_t secondsSinceSync() const;

private:
  time_t currentUtc() const;
  time_t _baseUtc = 0;
  uint32_t _baseMillis = 0;
  int _tzQuarterHours = 0;
  bool _synced = false;
};
