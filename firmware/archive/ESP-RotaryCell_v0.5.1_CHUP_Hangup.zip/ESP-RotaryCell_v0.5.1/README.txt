ESP-RotaryCell v0.5
===================

PURPOSE
-------
v0.5 adds incoming-call answer and hang-up control. It does not yet connect
the modem audio path, so neither party should expect voice audio.

NEW IN v0.5
-----------
- Corrected UART mapping: ESP32 RX GPIO5, ESP32 TX GPIO4
- Corrected LilyGO PWRKEY sequence: LOW 100 ms, HIGH 1000 ms, LOW
- Removed automatic 30-second modem polling; M is manual status refresh
- Incoming cellular calls ring the Western Electric 500
- Lifting the handset sends ATA and stops the physical bell
- Replacing the handset sends AT+CHUP
- Console status shows incoming and answered-call state

CONNECTIONS
-----------
GPIO15 -> Ag1171 F/R
GPIO16 -> Ag1171 RM
GPIO37 <- Ag1171 SHK
GPIO5  <- modem TX
GPIO4  -> modem RX
GPIO6  <- modem RI
GPIO7  -> modem DTR
GPIO46 -> modem PWRKEY
GPIO42 -> modem power capability control
GPIO8  <- battery voltage divider

EXPECTED INCOMING-CALL TEST
---------------------------
1. Leave the Model 500 on hook.
2. Call the SIM number.
3. The mechanical bell should ring in a 2-second-on/4-second-off cadence.
4. Lift the handset. The firmware stops the bell and sends ATA.
5. No voice audio is expected in this revision.
6. Replace the handset. The firmware sends AT+CHUP.

COMMANDS
--------
? = help
S = complete status
M = manually refresh and display modem status
A = AT terminal mode; enter EXIT to leave
W = pulse modem PWRKEY
P = toggle rotary-pulse timing output
R = one-second ring test
C = one complete manual cadence
X = stop physical ringing

KNOWN LIMITATIONS
-----------------
- No modem-to-Ag1171 voice path yet.
- No outgoing dialing yet.
- Call-active state is set when ATA is sent and cleared on AT+CHUP or a terminal
  modem result such as NO CARRIER.
