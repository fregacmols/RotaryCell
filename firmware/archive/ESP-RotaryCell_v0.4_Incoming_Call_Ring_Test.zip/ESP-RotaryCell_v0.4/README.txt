ESP-RotaryCell v0.4
===================

PURPOSE
-------
v0.4 is the first cellular integration test. It initializes the LilyGO
T-A7670G-S3 Standard modem, watches for incoming-call URCs, and rings the
Western Electric Model 500 through the Ag1171.

This version deliberately DOES NOT answer the call. Lifting the handset
silences the physical bell, but the caller remains unanswered. Answering
and audio routing are planned for v0.5.

NEW IN v0.4
-----------
- A7670G UART on ESP32 GPIO4/GPIO5
- Modem power-capability pin GPIO42 set HIGH
- Modem DTR GPIO7 held LOW to remain awake
- Optional PWRKEY wake pulse on GPIO46
- Incoming RING and +CRING URC parsing
- Caller ID parsing from +CLIP
- Continuous 2-second-on / 4-second-off physical ring cadence
- Ring stops when the caller disconnects or handset is lifted
- SIM, signal, operator, registration, RI-pin and call status
- Built-in AT terminal

PRESERVED FEATURES
------------------
- Hook-switch detection
- Rotary digit decoding
- Battery voltage and approximate percentage
- Manual ring tests
- Automatic bell shutdown on off-hook

ARDUINO IDE SETTINGS
--------------------
Board: ESP32S3 Dev Module
USB CDC On Boot: Enabled
Serial Monitor: 115200 baud
Line ending: Newline or Both NL & CR

Recommended Standard-board settings from LilyGO:
Flash Size: 16MB
PSRAM: QSPI PSRAM

IMPORTANT:
Arduino IDE may silently return USB CDC On Boot to Disabled. If upload
succeeds but Serial Monitor is blank, check that setting first.

CONNECTIONS
-----------
GPIO15 -> Ag1171 F/R
GPIO16 -> Ag1171 RM
GPIO37 <- Ag1171 SHK

The cellular and battery connections are already present on the LilyGO:
GPIO4  <- modem TX
GPIO5  -> modem RX
GPIO6  <- modem RI
GPIO7  -> modem DTR
GPIO46 -> modem PWRKEY
GPIO42 -> power capability control
GPIO8  <- battery voltage divider

FIRST CELLULAR TEST
-------------------
1. Attach the LTE antenna before powering the modem.
2. Install the active voice-capable SIM.
3. Connect ESP-USB to a stable USB source.
4. Upload v0.4 and open Serial Monitor at 115200.
5. Wait for MODEM: responding.
6. Send M and wait briefly for the returned status lines.
7. Confirm SIM READY and HOME or ROAMING registration.
8. Leave the telephone on hook.
9. Call the SIM's number from another phone.

Expected console output includes:
  [MODEM] RING
  [MODEM] +CLIP: "..."
  CELLULAR: incoming call
  RING: incoming-call cadence started

The Model 500 should repeat:
  2 seconds ringing
  4 seconds silent

until the cellular caller hangs up or the handset is lifted.

COMMANDS
--------
? = help
S = complete status
M = refresh and display modem status
A = AT terminal mode; enter EXIT to leave
W = pulse modem PWRKEY
P = toggle rotary-pulse timing output
R = one-second ring test
C = one complete manual cadence
X = stop physical ringing

AT TERMINAL EXAMPLES
--------------------
Enter A, then try:
  AT
  ATI
  AT+SIMCOMATI
  AT+CPIN?
  AT+CSQ
  AT+COPS?
  AT+CREG?
  AT+CEREG?
  AT+CLIP?

Enter EXIT to return to the normal console.

POWER NOTES
-----------
For initial modem testing, use ESP-USB and a supply/cable able to tolerate
cellular current peaks. Keep the 18650 installed if desired; the board's
charger manages it.

If the modem does not answer:
- Wait ten seconds and send M.
- Send W once, wait ten seconds, then send M.
- Enter A and send AT manually.
- Confirm the LTE antenna, SIM orientation, board power switch, and that
  USB is connected to ESP-USB rather than Modem-USB.

KNOWN v0.4 LIMITATIONS
----------------------
- Does not answer calls.
- Does not route modem audio.
- Does not place outgoing calls.
- Hardware RI is displayed for diagnostics, but UART RING/+CRING is the
  authoritative incoming-call trigger.
- Operator and registration values update asynchronously after M.
