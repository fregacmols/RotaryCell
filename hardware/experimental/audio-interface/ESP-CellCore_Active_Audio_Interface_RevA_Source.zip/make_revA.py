import svgwrite, os, math
from cairosvg import svg2pdf
from pypdf import PdfReader, PdfWriter

OUT='/mnt/data/ESP-CellCore_Active_Audio_RevA'
os.makedirs(OUT, exist_ok=True)
W,H=1600,1000

class Sch:
    def __init__(self,title,sheet):
        self.d=svgwrite.Drawing(size=(f'{W}px',f'{H}px'), viewBox=f'0 0 {W} {H}')
        self.d.add(self.d.rect(insert=(0,0), size=(W,H), fill='white'))
        self.title=title; self.sheet=sheet
        self.text(40,45,'ESP-CellCore Active Audio Interface - Rev A',32,bold=True)
        self.text(40,80,title,22,bold=True)
        self.text(1260,45,f'Sheet {sheet} of 3',18)
        self.text(1260,72,'PROPOSED - BENCH VALIDATION REQUIRED',14,fill='#a00000',bold=True)
        self.line(30,100,1570,100,2)
        self.line(30,940,1570,940,1)
        self.text(40,970,'Drawing EC-AUDIO-A | Supply: VBAT 3.4-4.3 V | Common ground with LilyGO and Ag1171',14)
    def line(self,x1,y1,x2,y2,w=2,stroke='black',dash=None):
        kw={'start':(x1,y1),'end':(x2,y2),'stroke':stroke,'stroke_width':w}
        if dash: kw['stroke_dasharray']=dash
        self.d.add(self.d.line(**kw))
    def poly(self,pts,w=2,stroke='black',fill='none'):
        self.d.add(self.d.polyline(points=pts,stroke=stroke,stroke_width=w,fill=fill))
    def text(self,x,y,s,size=16,bold=False,anchor='start',fill='black'):
        self.d.add(self.d.text(s,insert=(x,y),font_family='DejaVu Sans,Arial',font_size=size,font_weight='bold' if bold else 'normal',text_anchor=anchor,fill=fill))
    def box(self,x,y,w,h,label=None,stroke='#333',fill='none',dash=None):
        kw={'insert':(x,y),'size':(w,h),'rx':8,'ry':8,'fill':fill,'stroke':stroke,'stroke_width':2}
        if dash: kw['stroke_dasharray']=dash
        self.d.add(self.d.rect(**kw))
        if label:self.text(x+12,y+24,label,17,bold=True,fill=stroke)
    def node(self,x,y,r=4): self.d.add(self.d.circle(center=(x,y),r=r,fill='black'))
    def ground(self,x,y):
        self.line(x,y,x,y+15); self.line(x-14,y+15,x+14,y+15); self.line(x-9,y+21,x+9,y+21); self.line(x-4,y+27,x+4,y+27)
    def resistor_h(self,x1,y,x2,label,value):
        lead=18; body0=x1+lead; body1=x2-lead
        self.line(x1,y,body0,y)
        n=8; amp=8; pts=[(body0,y)]
        step=(body1-body0)/(n*2)
        for i in range(n*2): pts.append((body0+(i+1)*step, y+(amp if i%2==0 else -amp)))
        pts.append((body1,y)); self.poly(pts)
        self.line(body1,y,x2,y)
        self.text((x1+x2)/2,y-22,label,15,bold=True,anchor='middle'); self.text((x1+x2)/2,y+34,value,14,anchor='middle')
    def resistor_v(self,x,y1,y2,label,value):
        lead=18; b0=y1+lead; b1=y2-lead
        self.line(x,y1,x,b0)
        n=8; amp=8; pts=[(x,b0)]; step=(b1-b0)/(n*2)
        for i in range(n*2): pts.append((x+(amp if i%2==0 else -amp), b0+(i+1)*step))
        pts.append((x,b1)); self.poly(pts); self.line(x,b1,x,y2)
        self.text(x+18,(y1+y2)/2-6,label,15,bold=True); self.text(x+18,(y1+y2)/2+18,value,14)
    def cap_h(self,x1,y,x2,label,value):
        xm=(x1+x2)/2; self.line(x1,y,xm-8,y); self.line(xm-8,y-18,xm-8,y+18); self.line(xm+8,y-18,xm+8,y+18); self.line(xm+8,y,x2,y)
        self.text(xm,y-28,label,15,bold=True,anchor='middle'); self.text(xm,y+36,value,14,anchor='middle')
    def cap_v(self,x,y1,y2,label,value):
        ym=(y1+y2)/2; self.line(x,y1,x,ym-8); self.line(x-18,ym-8,x+18,ym-8); self.line(x-18,ym+8,x+18,ym+8); self.line(x,ym+8,x,y2)
        self.text(x+24,ym-6,label,15,bold=True); self.text(x+24,ym+18,value,14)
    def opamp(self,cx,cy,label,pins):
        pts=[(cx-65,cy-60),(cx-65,cy+60),(cx+65,cy)]
        self.d.add(self.d.polygon(points=pts,fill='white',stroke='black',stroke_width=2))
        self.text(cx-48,cy-28,'+',20,bold=True); self.text(cx-48,cy+38,'-',20,bold=True)
        self.text(cx,cy-5,label,18,bold=True,anchor='middle',fill='#153a8a')
        self.text(cx,cy+18,'TLV9064',13,anchor='middle')
        self.text(cx-78,cy-36,str(pins['plus']),12,anchor='end'); self.text(cx-78,cy+40,str(pins['minus']),12,anchor='end'); self.text(cx+78,cy+4,str(pins['out']),12)
        return {'plus':(cx-65,cy-35),'minus':(cx-65,cy+35),'out':(cx+65,cy)}
    def pot_v(self,x,y1,y2,label,value):
        self.resistor_v(x,y1,y2,label,value)
        ym=(y1+y2)/2
        self.line(x+65,ym,x+12,ym,2)
        self.poly([(x+12,ym),(x+24,ym-7),(x+24,ym+7),(x+12,ym)],fill='black')
        return (x+65,ym)
    def connector(self,x,y,labels,title):
        h=45*len(labels)+35; self.box(x,y,180,h,title,stroke='#186b2c')
        for i,l in enumerate(labels):
            yy=y+55+i*45
            self.d.add(self.d.rect(insert=(x+15,yy-20),size=(30,30),fill='white',stroke='black',stroke_width=1.5))
            self.text(x+30,yy+2,str(i+1),13,anchor='middle')
            self.line(x+45,yy-5,x+75,yy-5)
            self.text(x+85,yy,l,15)
        return [(x+75,y+50+i*45) for i in range(len(labels))]
    def save(self,path): self.d.saveas(path)

# Sheet 1
s=Sch('Receive path (cell to rotary) and dial-tone injection',1)
p=s.connector(55,175,['SPEK+','SPEK-'],'J1 - LilyGO SPEK')
op=s.opamp(730,360,'U1A',{'plus':3,'minus':2,'out':1})
# SPEK+ branch to non-inverting input
s.line(p[0][0],p[0][1],250,p[0][1]); s.resistor_h(250,p[0][1],430,'R2','22 kΩ, 1%'); s.line(430,p[0][1],520,p[0][1]); s.node(520,p[0][1]); s.line(520,p[0][1],520,op['plus'][1]); s.line(520,op['plus'][1],op['plus'][0],op['plus'][1])
# VREF reference resistor into same non-inverting node
s.text(520,135,'VREF',16,bold=True,anchor='middle',fill='#a00000'); s.line(520,145,520,160); s.resistor_v(520,160,p[0][1],'R4','10 kΩ, 1%')
# SPEK- branch to inverting input
s.line(p[1][0],p[1][1],250,p[1][1]); s.resistor_h(250,p[1][1],430,'R1','22 kΩ, 1%'); s.line(430,p[1][1],480,p[1][1]); s.line(480,p[1][1],480,op['minus'][1]); s.line(480,op['minus'][1],op['minus'][0],op['minus'][1]); s.node(480,op['minus'][1])
# Feedback resistor to inverting input
s.line(op['out'][0],op['out'][1],900,op['out'][1]); s.line(900,op['out'][1],900,520); s.resistor_h(900,520,650,'R3','10 kΩ, 1%'); s.line(650,520,480,520); s.line(480,520,480,op['minus'][1])
s.text(605,575,'Difference gain = R3/R1 = R4/R2 = 0.455',15)
s.text(605,600,'U1A OUT ≈ VREF + 0.455 × (SPEK+ - SPEK-)',15,bold=True)
# Output and receive level
s.cap_h(900,360,1050,'C1','1 µF'); s.line(1050,360,1210,360); s.node(1130,360); s.text(1130,340,'RX_SUM',16,bold=True,anchor='middle',fill='#a00000')
s.resistor_v(1130,360,520,'R5','100 kΩ'); s.ground(1130,520)
wiper=s.pot_v(1240,360,540,'VR1','10 kΩ linear'); s.ground(1240,540); s.line(1305,450,1360,450); s.cap_h(1360,450,1470,'C2','100 nF'); s.line(1470,450,1540,450); s.text(1530,430,'AG1171 VIN',15,bold=True,anchor='end'); s.text(1530,470,'pin 9',14,anchor='end')
# Dial tone
s.box(65,670,1010,220,'Dial-tone PWM filter and summing input',stroke='#1c3f94',dash='8,5')
s.text(90,725,'GPIO36',16,bold=True); s.line(175,720,230,720); s.resistor_h(230,720,390,'R6','3.3 kΩ'); s.node(390,720); s.cap_v(390,720,825,'C3','22 nF'); s.ground(390,825)
s.resistor_h(390,720,550,'R7','3.3 kΩ'); s.node(550,720); s.cap_v(550,720,825,'C4','22 nF'); s.ground(550,825)
s.cap_h(550,720,700,'C5','1 µF'); s.resistor_h(700,720,870,'R8','10 kΩ'); s.line(870,720,970,720); s.text(970,700,'to RX_SUM',15,bold=True,anchor='end'); s.line(970,720,970,620); s.line(970,620,1130,620); s.line(1130,620,1130,360,stroke='#1c3f94',dash='6,4'); s.node(1130,360)
s.text(90,865,'PWM carrier: use ≥ 31 kHz. Firmware synthesizes 350 Hz + 440 Hz; filter values are a starting point.',14)
page1=f'{OUT}/sheet1.svg'; s.save(page1); svg2pdf(url=page1,write_to=f'{OUT}/sheet1.pdf',output_width=1120,output_height=700)

# Sheet 2
s=Sch('Transmit path (rotary to cell): single-ended VOUT to differential MIC',2)
# source box
s.box(55,180,240,110,'J2 - From Ag1171',stroke='#6b2d8f'); s.text(85,230,'VOUT  pin 10',17,bold=True); s.text(85,260,'GND shares board ground',14)
s.line(295,235,360,235); s.cap_h(360,235,500,'C6','1 µF'); s.line(500,235,590,235); s.node(560,235)
# bias resistor
s.resistor_v(560,235,390,'R9','100 kΩ'); s.text(560,420,'VREF',15,bold=True,anchor='middle',fill='#a00000'); s.line(560,390,560,400)
# pot divider between signal and VREF
s.line(590,235,700,235); w=s.pot_v(700,235,430,'VR2','10 kΩ linear'); s.text(700,460,'bottom to VREF',14,anchor='middle'); s.text(700,485,'(not ground)',14,bold=True,anchor='middle',fill='#a00000'); s.text(700,420,'VREF',14,bold=True,anchor='middle',fill='#a00000')
# U1C follower
op1=s.opamp(930,300,'U1C',{'plus':10,'minus':9,'out':8}); s.line(w[0],w[1],820,w[1]); s.line(820,w[1],820,op1['plus'][1]); s.line(820,op1['plus'][1],op1['plus'][0],op1['plus'][1]); s.line(op1['out'][0],op1['out'][1],1090,op1['out'][1]); s.line(1090,op1['out'][1],1090,430); s.line(1090,430,830,430); s.line(830,430,830,op1['minus'][1]); s.line(830,op1['minus'][1],op1['minus'][0],op1['minus'][1]); s.node(1090,op1['out'][1])
s.text(930,500,'U1C: unity-gain buffer',15,bold=True,anchor='middle')
# U1D inverter lower
op2=s.opamp(930,650,'U1D',{'plus':12,'minus':13,'out':14}); s.text(760,590,'VREF',15,bold=True,fill='#a00000'); s.line(800,585,800,op2['plus'][1]); s.line(800,op2['plus'][1],op2['plus'][0],op2['plus'][1]); s.line(1090,300,1170,300); s.line(1170,300,1170,560); s.resistor_h(1170,560,1030,'R10','10 kΩ, 1%'); s.line(1030,560,820,560); s.line(820,560,820,op2['minus'][1]); s.line(820,op2['minus'][1],op2['minus'][0],op2['minus'][1]); s.line(op2['out'][0],op2['out'][1],1170,op2['out'][1]); s.line(1170,op2['out'][1],1170,790); s.resistor_h(1170,790,1030,'R11','10 kΩ, 1%'); s.line(1030,790,820,790); s.line(820,790,820,op2['minus'][1]); s.node(820,op2['minus'][1]); s.text(930,855,'U1D output = 2×VREF - U1C output (equal and opposite audio)',15,bold=True,anchor='middle')
# MIC connector right
pins=s.connector(1360,350,['MIC+','MIC-'],'J3 - LilyGO MIC')
# positive path
s.resistor_h(1090,300,1220,'R12','100 Ω'); s.cap_h(1220,300,1330,'C7','1 µF'); s.line(1330,300,1330,pins[0][1]); s.line(1330,pins[0][1],pins[0][0],pins[0][1])
# negative path
s.resistor_h(1170,650,1270,'R13','100 Ω'); s.cap_h(1270,650,1330,'C8','1 µF'); s.line(1330,650,1330,pins[1][1]); s.line(1330,pins[1][1],pins[1][0],pins[1][1])
# warning
s.box(60,650,600,190,'Critical wiring notes',stroke='#a00000')
s.text(85,705,'• MIC+ and MIC- are separate AC-coupled outputs.',16)
s.text(85,740,'• Do not ground either LilyGO microphone conductor.',16,bold=True)
s.text(85,775,'• Start VR2 near minimum transmit level and increase slowly.',16)
s.text(85,810,'• R10 and R11 must be matched for equal differential amplitudes.',16)
page2=f'{OUT}/sheet2.svg'; s.save(page2); svg2pdf(url=page2,write_to=f'{OUT}/sheet2.pdf',output_width=1120,output_height=700)

# Sheet 3
s=Sch('Power, buffered VREF, connector summary, test points, and BOM',3)
# power connector
pins=s.connector(55,170,['VBAT 3.4-4.3 V','GND','GPIO36'],'J4 - Board I/O')
# supply rail
s.line(pins[0][0],pins[0][1],340,pins[0][1]); s.text(345,pins[0][1]+5,'VBAT',16,bold=True,fill='#a00000')
s.cap_v(400,220,390,'C9','10 µF'); s.ground(400,390); s.line(400,220,400,pins[0][1]); s.cap_v(510,220,390,'C10','100 nF'); s.ground(510,390); s.line(510,220,510,pins[0][1])
# opamp power pins
s.box(650,160,330,190,'U1 - TLV9064 power',stroke='#153a8a'); s.text(685,225,'pin 4  V+  → VBAT',17); s.text(685,265,'pin 11 V-  → GND',17); s.text(685,305,'Place C10 close to pins 4/11.',15)
# vref divider + buffer
s.box(55,480,930,350,'Buffered mid-supply reference',stroke='#a00000')
s.text(100,535,'VBAT',15,bold=True,fill='#a00000'); s.line(150,530,220,530); s.resistor_v(220,530,650,'R14','10 kΩ, 1%'); s.node(220,650); s.resistor_v(220,650,770,'R15','10 kΩ, 1%'); s.ground(220,770); s.cap_v(320,650,770,'C11','10 µF'); s.ground(320,770); s.line(220,650,470,650); s.text(350,630,'VREF_RAW ≈ VBAT/2',15,bold=True,anchor='middle')
op=s.opamp(650,650,'U1B',{'plus':5,'minus':6,'out':7}); s.line(470,650,op['plus'][0],op['plus'][1]); s.line(op['out'][0],op['out'][1],840,op['out'][1]); s.line(840,op['out'][1],840,760); s.line(840,760,540,760); s.line(540,760,540,op['minus'][1]); s.line(540,op['minus'][1],op['minus'][0],op['minus'][1]); s.node(840,op['out'][1]); s.text(850,645,'VREF',17,bold=True,fill='#a00000'); s.text(850,675,'buffered, low impedance',14)
# test points and BOM
s.box(1040,150,500,310,'Test points / named nets',stroke='#555')
items=['TP1  VBAT','TP2  GND','TP3  VREF','TP4  U1A_OUT','TP5  RX_SUM','TP6  TX_BUF (U1C OUT)','TP7  TX_INV (U1D OUT)']
for i,t in enumerate(items): s.text(1080,205+i*34,t,16)
s.box(1040,500,500,360,'Core BOM',stroke='#555')
bom=['U1  TLV9064IDR, SOIC-14','VR1, VR2  10 kΩ linear trimmers','R1,R2  22 kΩ 1%','R3,R4,R10,R11,R14,R15  10 kΩ 1%','R5,R9  100 kΩ','R6,R7  3.3 kΩ; R8 10 kΩ','R12,R13  100 Ω','C1,C5,C6,C7,C8  1 µF','C2 100 nF; C3,C4 22 nF','C9,C11 10 µF; C10 100 nF']
for i,t in enumerate(bom): s.text(1070,548+i*29,t,14)
s.text(55,900,'Design intent: replace both analog transformers while retaining common ground and the Ag1171 SLIC interface.',15,bold=True)
page3=f'{OUT}/sheet3.svg'; s.save(page3); svg2pdf(url=page3,write_to=f'{OUT}/sheet3.pdf',output_width=1120,output_height=700)

# combine
writer=PdfWriter()
for i in [1,2,3]:
    r=PdfReader(f'{OUT}/sheet{i}.pdf')
    writer.add_page(r.pages[0])
final='/mnt/data/ESP-CellCore_Active_Audio_Interface_RevA.pdf'
with open(final,'wb') as f: writer.write(f)
print(final)
